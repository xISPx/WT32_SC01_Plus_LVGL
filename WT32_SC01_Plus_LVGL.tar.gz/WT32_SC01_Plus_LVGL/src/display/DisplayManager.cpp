#include "DisplayManager.h"
#include "../utils/Logger.h"

DisplayManager& DisplayManager::getInstance() {
  static DisplayManager instance;
  return instance;
}

bool DisplayManager::begin() {
  if (_initialized) return true;

  LOG_INFO("Initializing TFT...");
  
  // Базовая инициализация без сложных проверок
  _tft.init();
  _tft.setRotation(1); // 480x320
  _tft.fillScreen(TFT_BLACK);
  
  LOG_INFO("Display rotation set to 1 (480x320)");

  // Простая проверка PSRAM
  if (!psramFound()) {
    LOG_WARN("PSRAM not found - using internal RAM");
  } else {
    LOG_INFO("PSRAM found and available");
  }

  // Инициализация спрайта
  _sprite.setColorDepth(16);
  _sprite.setPsram(psramFound());
  
  if (!_sprite.createSprite(480, 320)) {
    LOG_WARN("Sprite creation failed - continuing without sprite");
    // Не прерываем выполнение, так как основной TFT работает
  } else {
    LOG_INFO("Sprite created successfully");
  }

  _initialized = true;
  LOG_INFO("Display initialized successfully");
  return true;
}

void DisplayManager::showStartupScreen() {
  auto& tft = getTft();
  tft.fillScreen(TFT_BLACK);
  tft.setTextSize(2);
  tft.setTextColor(TFT_GREEN);
  tft.setCursor(50, 100);
  tft.println("WT32-SC01 Plus");
  tft.setTextSize(1);
  tft.setTextColor(TFT_YELLOW);
  tft.setCursor(80, 140);
  tft.println("LVGL Demo Starting...");
  
  LOG_INFO("Startup screen displayed");
}

LGFX_Sprite& DisplayManager::getSprite() {
  return _sprite;
}

bool DisplayManager::getTouch(uint16_t* x, uint16_t* y) {
  return _tft.getTouch(x, y);
}

WT32SC01PlusDisplay& DisplayManager::getTft() {
  return _tft;
}