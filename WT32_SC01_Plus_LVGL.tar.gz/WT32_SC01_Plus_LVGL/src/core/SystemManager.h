#pragma once

class SystemManager {
public:
  static void initialize();
};