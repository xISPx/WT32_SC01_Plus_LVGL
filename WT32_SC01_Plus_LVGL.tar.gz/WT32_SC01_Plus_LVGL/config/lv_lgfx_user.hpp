#pragma once

#include <lvgl.h>
#include <LovyanGFX.hpp>

// Пустой файл конфигурации для LovyanGFX
// Реальная конфигурация находится в config/display_config.h